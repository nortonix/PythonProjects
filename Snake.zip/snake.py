from PyQt5 import QtGui
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtWidgets import QLabel
from PyQt5.QtGui import QPainter, QBrush, QPen
from PyQt5.QtCore import Qt 

#raport godzina 19:16 problem który zauwazylem u siebie podczas projektowania tej gry: przenoszenie informacji, licznika z klawisza W do drugiej klasy, opanować sobie wiedzę
#skoro dla w mamy ogarniete, zasada działania dla A S D bedzie dokladnie taka sama
# Only needed for access to command line arguments
import sys
import random

##przenoszenie informacji z jednej klasy do drugiej klasy
class MainWindow(QMainWindow):
    def __init__(self, counter, counter2, txt, a, b, score): 
        self.counter=counter  ##1.wstawiam do konstruktora informacje w 1szej klasie
        self.counter2=counter2
        self.txt=txt
        self.a=a
        self.b=b
        self.score=score
        
        super().__init__()
        
        self.startProgram()
        

    def keyPressEvent(self, event):   #sterowanie dowolnymi klawiszami, niestety ta komenda musi zostać tu wstawiona
        #co się dzieje, gdy naciśniemy raz klawisz "w"?
        tab = DrawingPane.crds(self)
        if len(tab) !=0:
            self.a = tab[0]
            self.b = tab[1]
            print('tutaj', self.a)


        print('cjik', self.score)
        if event.key() == Qt.Key_W:
            self.counter+=10 ##2.zmienną mogę sobie na bieżąco zmieniać w dowolnej funkcji
            self.drawing_pane = DrawingPane(self.counter, self.counter2, str(event.text()), self.a, self.b, self.score)   #sterowanie naszym "wężem, przenoszenie się z jednej klasy do drugiej klasy", tym poleceniem wywołujemy przeniesienie do naszej klasy, gdzie wykonuje nam się rysunek
            ##3.wrzucam aktualny stan zmiennej do drugiej klasy    
            self.setCentralWidget(self.drawing_pane)
        
        if event.key() == Qt.Key_S:
            self.counter-=10 ##2.zmienną mogę sobie na bieżąco zmieniać w dowolnej funkcji
            self.drawing_pane = DrawingPane(self.counter, self.counter2, str(event.text()), self.a, self.b, self.score)   #sterowanie naszym "wężem, przenoszenie się z jednej klasy do drugiej klasy", tym poleceniem wywołujemy przeniesienie do naszej klasy, gdzie wykonuje nam się rysunek
            ##3.wrzucam aktualny stan zmiennej do drugiej klasy    
            self.setCentralWidget(self.drawing_pane)

        if event.key() == Qt.Key_A:
            self.counter2+=10 ##2.zmienną mogę sobie na bieżąco zmieniać w dowolnej funkcji
            self.drawing_pane = DrawingPane(self.counter, self.counter2, str(event.text()), self.a, self.b, self.score)   #sterowanie naszym "wężem, przenoszenie się z jednej klasy do drugiej klasy", tym poleceniem wywołujemy przeniesienie do naszej klasy, gdzie wykonuje nam się rysunek
            ##3.wrzucam aktualny stan zmiennej do drugiej klasy    
            self.setCentralWidget(self.drawing_pane)

        if event.key() == Qt.Key_D:
            self.counter2-=10 ##2.zmienną mogę sobie na bieżąco zmieniać w dowolnej funkcji
            self.drawing_pane = DrawingPane(self.counter, self.counter2, str(event.text()), self.a, self.b, self.score)   #sterowanie naszym "wężem, przenoszenie się z jednej klasy do drugiej klasy", tym poleceniem wywołujemy przeniesienie do naszej klasy, gdzie wykonuje nam się rysunek
            ##3.wrzucam aktualny stan zmiennej do drugiej klasy    
            self.setCentralWidget(self.drawing_pane)
            
        


    def startProgram(self):
        #ustawianie naszego początkowego layoutu, naszego "okna"
        self.setGeometry(610,210,800,800) #koordynaty, 
        self.setWindowTitle("Snake")
        
        



        



        
        self.show()

class DrawingPane(QLabel):
    

    def __init__(self, counter, counter2, txt, a, b, score):  ##4.modyfikuję konstruktor drugiej klasy
        self.counter = counter  ##5.wprowadzam nową zmienna w konstruktorze drugiej klasy
        self.counter2 = counter2
        self.txt=txt
        self.a = a
        self.b = b
        self.score = score
        super().__init__()
        
    #tworzenie naszego "węża" na defaultowej pozycji


    def cords(self):
        first_location=400
        second_location=400
        tab=[first_location+10, second_location+10]
        return tab
    
    def paintEvent(self, event):
        print(self.score)
        painter2 = QPainter(self)
        pen = QPen()
        pen.setWidth(1)
        pen.setColor(Qt.blue) #obramowanie
        painter2.setPen(pen)
        painter2.setBrush(QBrush(Qt.blue, Qt.SolidPattern))
        painter2.drawRect(self.a, self.b, 10, 10)
        #print(self.txt) #essa, mozna sie bawic selfem!
        new_tab = self.cords()
        n_first_location = new_tab[0]-self.counter2
        n_second_location = new_tab[1]-self.counter
        painter = QPainter(self)
        #ustawienie parametrów pisaka
        pen = QPen()
        pen.setWidth(1)
        pen.setColor(Qt.black) #obramowanie
        painter.setPen(pen)
        painter.setBrush(QBrush(Qt.red, Qt.SolidPattern))

        for i in range(6):
            if self.txt=='w':
                painter.drawRect(n_first_location, n_second_location+i*10, 10, 10)
                if n_second_location == self.b and n_first_location == self.a:
                    self.score+=1
                    #problem: zapisanie informacji tak aby sie pojawila w pierwszej klasie!
                    self.a=random.randrange(10,790, 10)
                    self.b=random.randrange(10,790, 10)
                    
                    painter2.drawRect(self.a, self.b, 10, 10)
            elif self.txt=='s':
                painter.drawRect(n_first_location, n_second_location-i*10, 10, 10)
                if n_second_location == self.b and n_first_location == self.a:
                    self.score+=1
                    self.a=random.randrange(10,790, 10)
                    self.b=random.randrange(10,790, 10)
                    print('wggg' , self.a)
                    painter2.drawRect(self.a, self.b, 10, 10)
            elif self.txt=='a':
                painter.drawRect(n_first_location+i*10, n_second_location, 10, 10)
                if n_second_location == self.b and n_first_location == self.a:
                    self.score+=1
                    self.a=random.randrange(10,790, 10)
                    self.b=random.randrange(10,790, 10)
                    print('wggg' , self.a)
                    painter2.drawRect(self.a, self.b, 10, 10)
            elif self.txt=='d':
                painter.drawRect(n_first_location-i*10, n_second_location, 10, 10)
                if n_second_location == self.b and n_first_location == self.a:
                    self.score+=1
                    self.a=random.randrange(10,790, 10)
                    self.b=random.randrange(10,790, 10)
                    print('wggg' , self.a)
                    painter2.drawRect(self.a, self.b, 10, 10)
        print('ggg' , self.a)

    def crds(self):
        

        return [self.a, self.b]



        



if __name__ == "__main__":
    app = QApplication(sys.argv)
    ex = MainWindow(0, 0, 'a', random.randrange(10,790, 10), random.randrange(10,790, 10), 0) #trzeba tez uzupelnic ten konstruktor
    sys.exit(app.exec_())
    

